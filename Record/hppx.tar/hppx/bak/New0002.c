//
//
#include "util.h"
#include <stdio.h>
#include <string.h>

#define CMD_NAME_LENT(x)    ((int)strlen(x) - 1)
#define CMD_NAME_MAX_LEN    10

#define MAX_PROCESS_NAME_LEN 256
#define CMD_NAME_SYS_STAT   "sysstat"
#define CMD_NAME_NET_STAT   "netstat"
#define CMD_NAME_PRO_STAT   "prostat"
#define CMD_NAME_HELP       "help"
#define CMD_NAME_STOP       "stop"

typedef enum
{
    CMD_NONE,
    CMD_SYS,
    CMD_NET,
    CMD_PROC,
    CMD_STOP,
    CMD_HELP,
} CMD_E;

typedef struct
{
    CMD_E stat;
    char   *name;
    
} CMD_S;

CMD_S cmd_arr[] = 
{
    {CMD_NONE,  " "},
    {CMD_SYS,   "sysstat"},
    {CMD_NET,   "netstat"},
    {CMD_PROC,  "prostat"},
    {CMD_STOP,  "stop"},
    {CMD_HELP,  "help"},
};


void input_dialog(void)
{
    printf("\n");
    printf(">>>");
}

void disp_start_menu()
{
    printf("This is System Self-Check Tool, plese choose the task you want: \n");
    printf("\n");
    printf("***************************************************************\n");
    printf("\n");
    printf("Input 'sysstat' to check system state\n");
    printf("Input 'netstat' to check network state\n");
    printf("Input 'prostat' to check process state\n");
    printf("Input 'stop' to quit system\n");
    printf("Input 'help' to get instructions\n");
    printf("***************************************************************\n");
    printf("\n");
    printf(">>>");
}

void disp_help_menu()
{
    printf("Input 'sysstat' to check system state\n");
    printf("Input 'netstat' to check network state\n");
    printf("Input 'prostat' to check process state\n");
    printf("Input 'stop' to quit system\n");
    printf("Input 'help' to get instructions\n");
}


void disp_sys_stat()
{
    printf("系统状态集成在这个函数中\n");
}

void disp_net_stat()
{
    printf("网络状态集成在这个函数中\n");
}

void disp_pro_stat(char* processName, int maxProcessNameLen)
{
    printf("进程状态集成在这个函数中\n");
}

CMD_E get_run_stat(char *cmd)
{
    int len = 0;
    size_t i = 0;
    CMD_E stat = CMD_NONE;

    if (NULL == cmd)
    {
        return CMD_NONE;
    }

    for (i=0; i<sizeof(cmd_arr)/sizeof(cmd_arr[0]); i++)
    {
        len = (int)(strlen(cmd_arr[i].name) - 1);
        
        if (0 == strncmp(cmd, cmd_arr[i].name, len) && len > 0)
        {
            stat = cmd_arr[i].stat;
            
            break;
        }
    }

    return stat;
}

int main(void)
{
    char cmd[CMD_NAME_MAX_LEN]; 
    char ch;
    HP_BOOL quit_flag = HP_FALSE;
    char processName[MAX_PROCESS_NAME_LEN];

    memset(cmd, 0, sizeof(cmd));
    
    disp_start_menu();
    
    while (!quit_flag)
    {
        if(NULL != fgets(cmd, sizeof(cmd), stdin) && cmd[0] != '\n')
        {
            switch (get_run_stat(cmd))
            {
                case CMD_SYS:
                    disp_sys_stat();
                    break;
                case CMD_NET:
                    disp_net_stat();
                    break;
                case CMD_PROC:
                    printf("Please input Process Name:\n");
                    scanf("%s", processName);
                    disp_pro_stat(processName, MAX_PROCESS_NAME_LEN);
                    break;
                case CMD_STOP:
                    quit_flag = HP_TRUE;
                    break;
                case CMD_HELP:
                    disp_help_menu();
                    break;
                default :
                    printf("Invalid input, you can enter 'help' to get instructions.\n");
                    break;
            }

            input_dialog();
       }
    }
    
    return 0;
}
