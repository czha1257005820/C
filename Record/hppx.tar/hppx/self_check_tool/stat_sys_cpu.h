#ifndef __STAT_SYS_CPU_H
#define __STAT_SYS_CPU_H

void disp_sys_stat_cpu(void);

#endif
