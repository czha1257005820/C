#ifndef __UTIL_H
#define __UTIL_H

#define HP_OK       0
#define HP_ERROR    -1

typedef enum {HP_FALSE, HP_TRUE} HP_BOOL;

#define ARR_NUM(arr) ((int)(sizeof(arr)/sizeof(arr[0])))


#endif
