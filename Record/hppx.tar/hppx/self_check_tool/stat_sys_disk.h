#ifndef __STAT_SYS_DISK_H
#define __STAT_SYS_DISK_H

void disp_sys_stat_disk(void);

#endif
