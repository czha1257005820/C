//
//

#include<stdio.h>
#include<string.h>

#define MAX_PROCESS_NAME_LEN 256

void displayMenu()
{
    printf("This is System Self-Check Tool, plese Choose the Task You Want: \n");
    printf("\n");
    printf("***************************************************************\n");
    printf("\n");
    printf("Input 'S' to check System State\n");
    printf("Input 'N' to check Net State\n");
    printf("Input 'P' to check Process State\n");
    printf("Input 'Q' to Quit\n");
    printf("\n");
    printf("***************************************************************\n");
    printf("\n");
    printf(">>>");
}

void displaySystemState()
{
    printf("系统状态集成在这个函数中\n");
}

void displayNetState()
{
    printf("网络状态集成在这个函数中\n");
}

void displayProcessState(char* processName, int maxProcessNameLen)
{
    printf("进程状态集成在这个函数中\n");
}

int main(void)
{
    char item;
    char ch;
    int quitFlag = 0;
    char processName[MAX_PROCESS_NAME_LEN];
    displayMenu();
    while(!quitFlag)
    {
        
        scanf("%c", &item);
        switch(item)
        {
            case 'S':
            {
                displaySystemState();
                printf("\n");
                break;
            }
            case 'N':
            {
                displayNetState();
                printf("\n");
                break;
            }
            case 'P':
            {
                printf("Please input Process Name:\n");
                scanf("%s", processName);
                displayProcessState(processName, MAX_PROCESS_NAME_LEN);
                printf("\n");
                break;
            }
            case 'Q':
            {
                quitFlag = 1;
                break;
            }
            default:
            {
                printf("Invalid Input\n");
                printf("\n");
                break;
            }
        }
        while((ch = getchar())!='\n')
        {
        }
        if(0 == quitFlag)
            displayMenu();
    }
    return 0;
}
