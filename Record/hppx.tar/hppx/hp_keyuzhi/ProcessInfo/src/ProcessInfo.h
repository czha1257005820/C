/*
 ============================================================================
 Name        : ProcessInfo.h
 Author      : corvin.ke
 Version     :
 Copyright   : Your copyright notice
 Description :
 ============================================================================
 */
#ifndef _PROCESS_INFO_H_
#define _PROCESS_INFO_H_

long get_PidByName( char *ProcessName);//通过进程名称获取进程ID
int get_FdHandleNum(int pid);//通过进程id获取打开的文件句柄数
float get_pmem(pid_t p);
float get_pcpu(pid_t p);
int get_ProcessInfo(char *ProcessName);	//API 提供给框架调用
#endif
