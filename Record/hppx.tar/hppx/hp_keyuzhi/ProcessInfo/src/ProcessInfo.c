/*
 ============================================================================
 Name        : ProcessInfo.c
 Author      : corvin.ke
 Version     :
 Copyright   : Your copyright notice
 Description :
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>

#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>   //头文件
#include "CpuAndMemInfo.h"
#define BUF_SIZE 1024

/*
 * 函数原型：long get_PidByName( char *ProcessName)
 * Description :通过进程名称获取进程ID
 * pidName : 进程名称
 * return ：	成功返回 pid  失败返回-1
 */
int get_PidByName( char *ProcessName)
{
    DIR *dir;
    struct dirent *ptr;
    FILE *fp;
    char filepath[50];
    char cur_task_name[50];
    char buf[BUF_SIZE];
    int ret =-1;

    if(NULL == ProcessName)
    	return ret;

    dir = opendir("/proc");
    if (NULL != dir)
    {
    	// 循环读取 /proc 下的每一个文件 和 文件夹
        while ((ptr = readdir(dir)) != NULL)
        {
//        	printf("......................\n");
            //如果读取到的文件是"."或者".."则跳过
            if ((strcmp(ptr->d_name, ".") == 0) || (strcmp(ptr->d_name, "..") == 0))
                continue;
            if (DT_DIR != ptr->d_type) //如果读取到的文件类型不是文件夹也跳过
                continue;

           //当前遍历到的文件夹名称所对应的进程状态文件路径
            sprintf(filepath, "/proc/%s/status", ptr->d_name);
//          printf(".......filepath=%s...............\n",filepath);
            fp = fopen(filepath, "r");
            if (NULL != fp)
            {
                if( fgets(buf, BUF_SIZE-1, fp)== NULL )
                {
                    fclose(fp);
                    continue;
                }
                sscanf(buf, "%*s %s", cur_task_name);
                //如果文件内容满足要求则打印路径的名字（即进程的PID）
                if (!strcmp(ProcessName, cur_task_name))
                {
                    sscanf(ptr->d_name, "%d", &ret);
                }
                fclose(fp);
            }
        }
        closedir(dir);
    }
    return ret;
}

/*
 *函数原型：int get_FdHandleNum(int pid)
 *Description：通过进程id获取打开的文件句柄数
 *pid：进程ID
 *返回值：成功文件句柄个数   失败：返回-1
 */
int get_FdHandleNum(int pid)
{
	char filepath[50]={0};
	char cmd[100]={0};
	char buf[BUF_SIZE]={0};
	FILE *fp;
	int handlenum=-1;
	fp = fopen("./tmp.txt", "w+");
	sprintf(filepath, "/proc/%d/fd", pid);
	sprintf(cmd,"ls %s | wc -l >> ./tmp.txt",filepath);
	system(cmd);
	 if (NULL != fp)
	 {
	      if( fgets(buf, BUF_SIZE-1, fp)== NULL )
	      {
	    	  fclose(fp);
	    	  return handlenum;
	      }
	      sscanf(buf, "%d", &handlenum);
     }
	 fclose(fp);
	 return handlenum;
}

/*
 * 函数原型：float get_pmem(pid_t p)
 *Description：通过进程id获取进程内存使用率
 *pid：进程ID
 *返回值：内存使用率
 */
float get_pmem(pid_t p)
{
    int phy = get_phy_mem(p);
    int total = get_total_mem();
    float occupy =100.0*(phy*1.0)/(total*1.0);
//  fprintf(stderr,"====process mem occupy:%.6f\n====",occupy);
    return occupy;
}

/*
 * 函数原型：float get_pcpu(pid_t p)
 *Description：通过进程id获取进程CPU使用率
 *pid：进程ID
 *返回值：CPU使用率
 */
float get_pcpu(pid_t p)
{
    unsigned int totalcputime1,totalcputime2;
    unsigned int procputime1,procputime2;
    totalcputime1 = get_cpu_total_occupy();
    procputime1 = get_cpu_process_occupy(p);
    usleep(500000);//延迟500毫秒
    totalcputime2 = get_cpu_total_occupy();
    procputime2 = get_cpu_process_occupy(p);
    float pcpu = 100.0*(procputime2 - procputime1)/(totalcputime2 - totalcputime1);
//  fprintf(stderr,"====pcpu:%.6f\n====",pcpu);
    return pcpu;
}

//	API 提供给框架调用
/*原型：int get_ProcessInfo(char *ProcessName)
 *Description：获取进程信息
 *ProcessName：进程名称
 *返回值 :成功 0  ，失败 -1
 */
int get_ProcessInfo(char *ProcessName)
{
	int pid= -1;
	float mempercent=0;
	float cpupercent=0;
	int handlenum=-1;
	int ret=-1;

	printf("Get ProcessInfo :\n");
	if(NULL==ProcessName)
	{
		printf("		error:the number of param \n");
		return ret;
	}

	pid=get_PidByName(ProcessName);
	if(pid > 0)
	{
		printf("		ProcessName:%s\n",ProcessName);
		printf("		ProcessId:%d\n",pid);
	}
	else
	{
		printf("		error:process %s not exit \n",ProcessName);
		return ret;
	}

	mempercent = get_pmem(pid);
	if(mempercent<0)
	{
		printf("		error:the MemPercent \n");
		return ret;
	}
	else
	{
		printf("		MemPercent:%.6f\n",mempercent);
	}

	cpupercent = get_pcpu(pid);
	if(cpupercent<0)
	{
		printf("		error:the CpuPercent \n");
		return ret;
	}
	else
	{
		printf("		CpuPercent:%.6f\n",cpupercent);
	}

	handlenum = get_FdHandleNum(pid);
	if(cpupercent<0)
	{
		printf("		error:the HandleNum \n");
		return ret;
	}
	else
	{
		printf("		HandleNum:%d\n",handlenum);
	}
	return 0;
}



