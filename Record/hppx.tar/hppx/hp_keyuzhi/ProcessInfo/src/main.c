/*
 ============================================================================
 Name        : main.c
 Author      : corvin.ke
 Version     :
 Copyright   : Your copyright notice
 Description : test
 ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>

#include"ProcessInfo.h"

// test program
int main(int argc,char *argv[])
{
	int pid= -1;
	float mempercent=0;
	float cpupercent=0;
	int handlenum=-1;

	printf("Get ProcessInfo :\n");
	if(2 != argc)
	{
		printf("		error:the number of param  is %d \n",argc);
		return 0;
	}

	pid=get_PidByName(argv[1]);
	if(pid > 0)
	{
		printf("		ProcessName:%s\n",argv[1]);
		printf("		ProcessId:%d\n",pid);
	}
	else
	{
		printf("		error:process %s not exit \n",argv[1]);
		return 0;
	}

	mempercent = get_pmem(pid);
	if(mempercent<0)
	{
		printf("		error:the mempercent \n");
	}
	else
	{
		printf("		mempercent:%.6f\n",mempercent);
	}

	cpupercent = get_pcpu(pid);
	if(cpupercent<0)
	{
		printf("		error:the cpupercent \n");
	}
	else
	{
		printf("		cpupercent:%.6f\n",cpupercent);
	}

	handlenum = get_FdHandleNum(pid);
	if(cpupercent<0)
	{
		printf("		error:the handlenum \n");
	}
	else
	{
		printf("		handlenum:%d\n",handlenum);
	}
	return 0;
}

